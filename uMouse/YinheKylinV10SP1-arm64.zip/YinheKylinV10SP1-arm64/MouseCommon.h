#pragma once

#define LIB_COMMON_EXPORT

#ifdef __cplusplus
extern "C"
{
#endif

    #pragma region Structures

    /*!
     *  @brief      音频数据结构体
     *  @details    用于封装音频事件的数据负载，包含音频数据及其用途
     */
    typedef struct AudioData
    {
        int _eventCode;             //!< 音频用途类型，参考 Common Events 事件码
        unsigned char* _pData;      //!< 音频二进制数据（可以是编码前后的数据）
        int _length;                //!< 音频二进制数据有效长度
    }AudioData;

    #pragma endregion

    #pragma region Callbacks

    /*!
     *  @brief      智能鼠标成功连接后的通知回调（不代表序列号已经上报）
     *  @details    [可选]上位机可自行编写弹窗提示，如“设备已连接”、“鼠标已连接”
     *
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*ConnectedCallback)(const char* deviceType);
    /*!
     *  @brief      智能鼠标断开后的通知回调
     *  @details    [可选]上位机可自行编写弹窗提示，如“设备已断开”、“鼠标已断开”
     *
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*DisconnectedCallback)(const char* deviceType);
    /*!
     *  @brief      上报智能鼠标序列号的通知回调
     *  @details    [必选]上位机必须编写登录鉴权步骤
     *  @warning    智能鼠标序列号用于上位机登录鉴权，鉴权失败则无法使用智能体软件
     *
     *  @param[out] sn，智能鼠标序列号
     *  @param[out] batteryLevel，智能鼠标内置电池当前百分比电量
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*UploadSnCallback)(const char* sn, int batteryLevel, const char* deviceType);
    /*!
     *  @brief      智能鼠标通过按键改变 DPI 的通知回调
     *  @details    [可选]上位机可自行编写更新 DPI 数值显示
     *
     *  @param[out] dpiLevel，指示 DPI 档位，并非真实的 DPI 数值
     */
    typedef void (*DpiChangedCallback)(int dpiLevel);
    /*!
     *  @brief      语音键长按按下的通知回调
     *  @details    [可选]上位机可自行编写显示语音识别中间结果的无焦点弹窗
     *
     *  @param[out] eventCode，音频用途类型，参考 Common Events 事件码
     */
    typedef void (*SpeechKeyDownCallback)(int eventCode);
    /*!
     *  @brief      语音键从长按中松开的通知回调
     *  @details    [可选]上位机可自行编写隐藏语音识别中间结果的无焦点弹窗
     */
    typedef void (*SpeechKeyUpCallback)();
    /*!
     *  @brief      AI 键单击一次的通知回调
     *  @details    [可选]上位机可自行编写将智能体主窗体从隐藏于后台的状态变为显示状态
     */
    typedef void (*AIKeyClickedCallback)();
    /*!
     *  @brief      M 键按住不放时，每次定时触发的通知回调
     *  @details    [可选]上位机可自行编写 M 键模拟用户多次按下回车键的处理
     *
     *  @param[out] indexMKey，表示第几个 M 键被按下，从 1 开始
     */
    typedef void (*MKeyHeldCallback)(int indexMKey);

    /*!
     *  @brief      音频数据解码完毕后的通知回调
     *  @details    [可选]上位机可自行编写音频数据用于语音识别的处理
     */
    typedef void (*AudioDataDecodedCallback)(const AudioData* pAudioData);

    #pragma endregion

    #pragma region Register callbacks

    /*!
     *  @brief      上位机注册智能鼠标已连接的通知回调
     *
     *  @param[in]  callback，智能鼠标已连接的处理函数
     */
    LIB_COMMON_EXPORT void RegisterConnectedCallback(ConnectedCallback callback);
    /*!
     *  @brief      上位机注册智能鼠标已断开的通知回调
     *
     *  @param[in]  callback，智能鼠标已断开的处理函数
     */
    LIB_COMMON_EXPORT void RegisterDisconnectedCallback(DisconnectedCallback callback);
    /*!
     *  @brief      上位机注册上报智能鼠标序列号的通知回调
     *  @warning    [必选]上位机必须编写登录鉴权步骤
     *
     *  @param[in]  callback，上报序列号的处理函数
     */
    LIB_COMMON_EXPORT void RegisterUploadSnCallback(UploadSnCallback callback);
    /*!
     *  @brief      上位机注册智能鼠标通过按键改变 DPI 的通知回调
     *
     *  @param[in]  callback，DPI 改变后的处理函数
     */
    LIB_COMMON_EXPORT void RegisterDpiChangedCallback(DpiChangedCallback callback);

    /*!
     *  @brief      上位机注册智能鼠标语音键长按按下的通知回调
     *
     *  @param[in]  callback，语音键长按按下的处理函数
     */
    LIB_COMMON_EXPORT void RegisterSpeechKeyDownCallback(SpeechKeyDownCallback callback);
    /*!
     *  @brief      上位机注册智能鼠标语音键从长按中松开的通知回调
     *
     *  @param[in]  callback，语音键从长按中松开的处理函数
     */
    LIB_COMMON_EXPORT void RegisterSpeechKeyUpCallback(SpeechKeyUpCallback callback);
    /*!
     *  @brief      上位机注册智能鼠标 AI 键单击一次的通知回调
     *
     *  @param[in]  callback，AI 键单击一次的处理函数
     */
    LIB_COMMON_EXPORT void RegisterAIKeyClickedCallback(AIKeyClickedCallback callback);
    /*!
     *  @brief      上位机注册智能鼠标 M 键按住不放时，每次定时触发的通知回调
     *
     *  @param[in]  callback，M 键按住不放时，每次定时触发的处理函数
     */
    LIB_COMMON_EXPORT void RegisterMKeyHeldCallback(MKeyHeldCallback callback);
    
    /*!
     *  @brief      上位机注册智能鼠标音频数据解码完毕后的通知回调
     *
     *  @param[in]  callback，音频数据解码完毕后的处理函数
     */
    LIB_COMMON_EXPORT void RegisterAudioDataDecodedCallback(AudioDataDecodedCallback callback);

    #pragma endregion

    #pragma region Handle audio

    /*!
     *  @brief      启动音频解码线程
     */
    LIB_COMMON_EXPORT void StartAudioDecodedThread();
    /*!
     *  @brief      停止音频解码线程
     */
    LIB_COMMON_EXPORT void StopAudioDecodedThread();

    #pragma endregion

    #pragma region Handle keystrokes

    /*!
     *  @brief      通过事件码设置 M 键用途
     *  @details    比如语音打字、翻译，模拟用户按下后退、回车键等
     *  @warning    indexMKey 为 0 时，特指设置的是语音键
     *
     *  @param[in]  eventCode，事件码表示用途，请参考 Common Events 事件码
     *  @param[in]  indexMKey，表示对第几个 M 键做设置，普通鼠标只有 1 个 M 键
     */
    LIB_COMMON_EXPORT void SetMKeyEvent(int eventCode, int indexMKey);

    /*!
     *  @brief      模拟用户按下回车键
     */
    LIB_COMMON_EXPORT void SendReturn();
    /*!
     *  @brief      模拟用户按下后退键
     *
     *  @param[in]  count，表示连续按下后退键的次数
     */
    LIB_COMMON_EXPORT void SendBackspace(int count);
    /*!
     *  @brief      发送常用键盘热键命令，比如 Ctrl + v
     *  @param[in]  letter，字母按键，从 'a' 到 'z'
     *  @warning    注意 Mac 上的是 Command 按键，不是 Ctrl 按键
     */
    LIB_COMMON_EXPORT void SendCtrlCommand(char letter);

    /*!
     *  @brief      模拟用户键盘打字，在光标后追加打字的内容
     *  @param[in]  text，Unicode 编码的文字内容
     */
    LIB_COMMON_EXPORT void SendText(const wchar_t* text);
    /*!
     *  @brief      模拟用户从后向前删除紧跟着光标前指定的文字内容
     *  @param[in]  text，Unicode 编码的文字内容
     */
    LIB_COMMON_EXPORT void DeleteText(const wchar_t* text);

    #pragma endregion

    /*!
     *  @brief      操作系统相关功能使用前的平台初始化调用
     *  @details    比如 Windows 注册热键，Linux 模拟键盘打字
     */
    LIB_COMMON_EXPORT void InitPlatform();
    /*!
     *  @brief      操作系统相关功能使用完成后的平台释放调用
     */
    LIB_COMMON_EXPORT void UninitPlatform();

#ifdef __cplusplus
}
#endif
