#pragma once

#define LIB_EXPORT

#ifdef __cplusplus
extern "C"
{
#endif

    /*!
     *  @brief      启动 USB 检测线程
     */
    LIB_EXPORT void StartUsbCheckThread();
    /*!
     *  @brief      停止 USB 检测线程
     */
    LIB_EXPORT void StopUsbCheckThread();

    /*!
     *  @brief      通过 USB 设置鼠标 DPI
     *
     *  @param[in]  dpiLevel，鼠标 DPI 挡位，需参考对应硬件手册
     */
    LIB_EXPORT bool SetUsbMouseDpi(int dpiLevel);

#ifdef __cplusplus
}
#endif
