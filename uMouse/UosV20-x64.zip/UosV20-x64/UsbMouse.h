#pragma once

#define LIB_EXPORT

#ifdef __cplusplus
extern "C"
{
#endif

    /*!
     *  @brief      启动 USB 检测线程
     */
    LIB_EXPORT void StartUsbCheckThread();
    /*!
     *  @brief      停止 USB 检测线程
     */
    LIB_EXPORT void StopUsbCheckThread();

    /*!
     *  @brief      通过 USB 设置鼠标 DPI
     *
     *  @param[in]  dpiLevel，鼠标 DPI 挡位，需参考对应硬件手册
     *  @return     true 则设置成功
     */
    LIB_EXPORT bool SetUsbMouseDpi(int dpiLevel);

    #pragma region Meeting status

    /*!
     *  @brief      通过 USB 创建会议
     *
     *  @return     true 则创建成功
     */
    LIB_EXPORT bool MeetingCreatedByUsbMouse();
    /*!
     *  @brief      通过 USB 销毁会议
     *
     *  @return     true 则销毁成功
     */
    LIB_EXPORT bool MeetingDestroyedByUsbMouse();
    /*!
     *  @brief      通过 USB 暂停会议
     *
     *  @return     true 则暂停成功
     */
    LIB_EXPORT bool MeetingPausedByUsbMouse();
    /*!
     *  @brief      通过 USB 恢复会议
     *
     *  @return     true 则恢复成功
     */
    LIB_EXPORT bool MeetingResumedByUsbMouse();

    #pragma endregion

#ifdef __cplusplus
}
#endif
