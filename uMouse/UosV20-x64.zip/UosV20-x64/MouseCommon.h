#pragma once

#define LIB_COMMON_EXPORT

#ifdef __cplusplus
extern "C"
{
#endif

    #pragma region Structures

    /*!
     *  @brief      音频数据结构体
     *  @details    用于封装音频事件的数据负载，包含音频数据及其用途
     */
    typedef struct AudioData
    {
        int _eventCode;             //!< 音频用途类型，参考 Common Events 事件码
        unsigned char* _pData;      //!< 音频二进制数据（可以是编码前后的数据）
        int _length;                //!< 音频二进制数据有效长度
    }AudioData;

    #pragma endregion

    #pragma region Callbacks

    /*!
     *  @brief      智能鼠标成功连接后的通知回调（不代表序列号已经上报）
     *  @details    [可选]上位机可自行编写弹窗提示，如“设备已连接”、“鼠标已连接”
     *
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*ConnectedCallback)(const char* deviceType);
    /*!
     *  @brief      智能鼠标断开后的通知回调
     *  @details    [可选]上位机可自行编写弹窗提示，如“设备已断开”、“鼠标已断开”
     *
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*DisconnectedCallback)(const char* deviceType);
    /*!
     *  @brief      上报智能鼠标序列号的通知回调
     *  @details    [必选]上位机必须编写登录鉴权步骤
     *  @warning    智能鼠标序列号用于上位机登录鉴权，鉴权失败则无法使用智能体软件
     *
     *  @param[out] sn，智能鼠标序列号
     *  @param[out] batteryLevel，智能鼠标内置电池当前百分比电量
     *  @param[out] deviceType，表示具体连接的硬件类型，如"usb"或"ble"
     */
    typedef void (*UploadSnCallback)(const char* sn, int batteryLevel, const char* deviceType);
    /*!
     *  @brief      智能鼠标通过按键改变 DPI 的通知回调
     *  @details    [可选]上位机可自行编写更新 DPI 数值显示
     *
     *  @param[out] dpiLevel，指示 DPI 档位，并非真实的 DPI 数值
     */
    typedef void (*DpiChangedCallback)(int dpiLevel);
    /*!
     *  @brief      语音键长按按下的通知回调
     *  @details    [可选]上位机可自行编写显示语音识别中间结果的无焦点弹窗
     *
     *  @param[out] eventCode，音频用途类型，参考 Common Events 事件码
     */
    typedef void (*SpeechKeyDownCallback)(int eventCode);
    /*!
     *  @brief      语音键从长按中松开的通知回调
     *  @details    [可选]上位机可自行编写隐藏语音识别中间结果的无焦点弹窗
     */
    typedef void (*SpeechKeyUpCallback)();
    /*!
     *  @brief      AI 键单击一次的通知回调
     *  @details    [可选]上位机可自行编写将智能体主窗体从隐藏于后台的状态变为显示状态
     */
    typedef void (*AIKeyClickedCallback)();
    /*!
     *  @brief      M 键按住不放时，每次定时触发的通知回调
     *  @details    [可选]上位机可自行编写 M 键模拟用户多次按下回车键的处理
     *
     *  @param[out] indexMKey，表示第几个 M 键被按下，从 1 开始
     */
    typedef void (*MKeyHeldCallback)(int indexMKey);

    /*!
     *  @brief      音频数据解码完毕后的通知回调
     *  @details    [必选]上位机可自行编写音频数据用于语音识别的处理
     */
    typedef void (*AudioDataDecodedCallback)(const AudioData* pAudioData);
    /*!
     *  @brief      新版会议模式创建后的通知回调
     *  @details    [可选]上位机可自行编写新版会议模式创建后的提示
     */
    typedef void (*MeetingCreatedCallback)();
    /*!
     *  @brief      新版会议模式销毁后的通知回调
     *  @details    [可选]上位机可自行编写新版会议模式销毁后的提示
     */
    typedef void (*MeetingDestroyedCallback)();

    #pragma endregion

    #pragma region Register callbacks

    /*!
     *  @brief      内部通知回调
     *  @details    仅暴露给上位机硬件相关模块调用
     */
    typedef struct IInternalCallbacks
    {
        ConnectedCallback _onConnected;
        DisconnectedCallback _onDisconnected;
        MeetingDestroyedCallback _onMeetingDestroyed;
    }IInternalCallbacks;

    /*!
     *  @brief      私有通知回调
     *  @details    仅供本模块内部使用
     */
    typedef struct IPrivateCallbacks
    {
        UploadSnCallback _onUploadSn;
        DpiChangedCallback _onDpiChanged;
        SpeechKeyDownCallback _onSpeechKeyDown;
        SpeechKeyUpCallback _onSpeechKeyUp;
        AIKeyClickedCallback _onAIKeyClicked;
        MKeyHeldCallback _onMKeyHeld;
        AudioDataDecodedCallback _onAudioDataDecoded;
        MeetingCreatedCallback _onMeetingCreated;
    }IPrivateCallbacks;

    /*!
     *  @brief      内部通知回调注册
     *
     *  @param[in]  callbacks，内部通知回调
     */
    LIB_COMMON_EXPORT void RegisterInternalCallbacks(IInternalCallbacks callbacks);
    /*!
     *  @brief      私有通知回调注册
     *
     *  @param[in]  callbacks，私有通知回调
     */
    LIB_COMMON_EXPORT void RegisterPrivateCallbacks(IPrivateCallbacks callbacks);

    #pragma endregion

    #pragma region Handle audio

    /*!
     *  @brief      启动音频解码线程
     */
    LIB_COMMON_EXPORT void StartAudioDecodedThread();
    /*!
     *  @brief      停止音频解码线程
     */
    LIB_COMMON_EXPORT void StopAudioDecodedThread();

    #pragma endregion

    /*!
     *  @brief      通过事件码设置 M 键用途
     *  @details    比如语音打字、翻译，模拟用户按下后退、回车键等
     *  @warning    indexMKey 为 0 时，特指设置的是语音键
     *
     *  @param[in]  eventCode，事件码表示用途，请参考 Common Events 事件码
     *  @param[in]  indexMKey，表示对第几个 M 键做设置，普通鼠标只有 1 个 M 键
     */
    LIB_COMMON_EXPORT void SetMKeyEvent(int eventCode, int indexMKey);

#ifdef __cplusplus
}
#endif
